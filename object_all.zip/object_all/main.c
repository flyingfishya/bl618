#include "bflb_gpio.h"
#include "bflb_mtimer.h"
#include "board.h"
#include "bflb_uart.h"
#include "mpu6050.h"
#include "math.h"
#include "MAX30102.h"
#include "bflb_adc.h"
#include "bflb_efuse.h"
#include "adc.h"

struct bflb_device_s *gpio;
struct bflb_device_s *uart1;
struct bflb_device_s *uart0;
struct bflb_device_s *adc;

unsigned char withlook[5];
unsigned char pangduan[1];
unsigned char withlook2[5];  //串口屏
unsigned char nihao[] = {0xf1};
unsigned char walk_num[] = {0x01};
unsigned char walk_num2[] = {0xfd};
float dianlian=0;
uint8_t walk_mode=0,weather_flag=0,esp8266_send=0,walk=0,show_light=0,fall_down=0;

uint8_t ID;
int16_t AX, AY, AZ, GX, GY, GZ;
float acceleration_magnitude;

void uart_isr(int irq, void *arg)
{
    uint32_t intstatus = bflb_uart_get_intstatus(uart1);

    if (intstatus & UART_INTSTS_RTO) {
          while (bflb_uart_rxavailable(uart1)) {
            withlook2[0]=bflb_uart_getchar(uart1);
            
              if(withlook2[0]==0xf0)               //esp8266
              {
                  withlook2[1]=bflb_uart_getchar(uart1);
                  withlook2[2]=bflb_uart_getchar(uart1);
                  withlook2[3]=bflb_uart_getchar(uart1);
                  withlook2[4]=bflb_uart_getchar(uart1);
                  printf("--------uart1 esp8266----------\n\r");
                  printf("0x%02x\n\r",  withlook2[0]);
                  printf("0x%02x\n\r",  withlook2[1]);
                  printf("0x%02x\n\r",  withlook2[2]);
                  printf("0x%02x\n\r",  withlook2[3]);
                  printf("0x%02x\n\r",  withlook2[4]);
                  if(withlook2[4]==0x0f)
                  esp8266_send=1;
              } 
              if(withlook2[0]==0xf4)             //walk
              {
                  withlook2[1]=bflb_uart_getchar(uart1);
                  withlook2[2]=bflb_uart_getchar(uart1);
                  withlook2[3]=bflb_uart_getchar(uart1);
                  withlook2[4]=bflb_uart_getchar(uart1);
                  printf("--------uart1  walk----------\n\r");
                  printf("0x%02x\n\r",  withlook2[0]);
                  printf("0x%02x\n\r",  withlook2[1]);
                  printf("0x%02x\n\r",  withlook2[2]);
                  printf("0x%02x\n\r",  withlook2[3]);
                  printf("0x%02x\n\r",  withlook2[4]);
                  if((withlook2[1]==0x08)&&(withlook2[4]==0x0f))
                  {
                    walk_mode=1;
                    printf("enter walk\n\r");
                    }
                  else 
                  {
                    walk_mode=0;
                    printf("end walk\n\r");
                  }
              }      
                  if(withlook2[0]==0xf6)     //MAX30102
              {
                  withlook2[1]=bflb_uart_getchar(uart1);
                  withlook2[2]=bflb_uart_getchar(uart1);
                  withlook2[3]=bflb_uart_getchar(uart1);
                  withlook2[4]=bflb_uart_getchar(uart1);
                  printf("--------MAX30102----------\n\r");
                  printf("0x%02x\n\r",  withlook2[0]);
                  printf("0x%02x\n\r",  withlook2[1]);
                  printf("0x%02x\n\r",  withlook2[2]);
                  printf("0x%02x\n\r",  withlook2[3]);
                  printf("0x%02x\n\r",  withlook2[4]);
                  if((withlook2[1]==0x08)&&(withlook2[4]==0x0f))
                  {
                    MAX30102_Open();
                    printf("MAX30102 OPEN\n\r");
                    }
                  else 
                  {
                    MAX30102_Close();
                    printf("MAX30102 CLOSE\n\r");
                  }
              }      
              if(withlook2[0]==0xf7)     //LED
              {
                  withlook2[1]=bflb_uart_getchar(uart1);
                  withlook2[2]=bflb_uart_getchar(uart1);
                  withlook2[3]=bflb_uart_getchar(uart1);
                  withlook2[4]=bflb_uart_getchar(uart1);
                  printf("--------LED----------\n\r");
                  printf("0x%02x\n\r",  withlook2[0]);
                  printf("0x%02x\n\r",  withlook2[1]);
                  printf("0x%02x\n\r",  withlook2[2]);
                  printf("0x%02x\n\r",  withlook2[3]);
                  printf("0x%02x\n\r",  withlook2[4]);
                  if((withlook2[3]==0x10)&&(withlook2[4]==0x0f))
                  {
                    bflb_gpio_set(gpio, GPIO_PIN_20);
                    printf("LED OPEN\n\r");
                    }
                  else 
                  {
                    bflb_gpio_reset(gpio, GPIO_PIN_20);
                    printf("LED CLOSE\n\r");
                  }
              }       
              if(withlook2[0]==0xf9)               //ADC
              {
                  withlook2[1]=bflb_uart_getchar(uart1);
                  withlook2[2]=bflb_uart_getchar(uart1);
                  withlook2[3]=bflb_uart_getchar(uart1);
                  withlook2[4]=bflb_uart_getchar(uart1);
                  printf("--------ADC_Read----------\n\r");
                  printf("0x%02x\n\r",  withlook2[0]);
                  printf("0x%02x\n\r",  withlook2[1]);
                  printf("0x%02x\n\r",  withlook2[2]);
                  printf("0x%02x\n\r",  withlook2[3]);
                  printf("0x%02x\n\r",  withlook2[4]);
                  if(withlook2[4]==0x0f)
                  {
                    dianlian = adc_get();
                    bflb_uart_put(uart1,dianlian,1);
                  }
              }  
          }
          bflb_uart_int_clear(uart1, UART_INTCLR_RTO);
      }
}

void uart0_isr(int irq, void *arg)
{
    uint32_t intstatus = bflb_uart_get_intstatus(uart0);

    if (intstatus & UART_INTSTS_RTO) {
          while (bflb_uart_rxavailable(uart0)) {
            withlook[0]=bflb_uart_getchar(uart0);
            
            //   printf("0x%02x\n\r",  withlook[0]);
            
              if(withlook[0]==0xf0)
              {
                  withlook[1]=bflb_uart_getchar(uart0);
                  withlook[2]=bflb_uart_getchar(uart0);
                  withlook[3]=bflb_uart_getchar(uart0);
                  withlook[4]=bflb_uart_getchar(uart0);
                  printf("--------uart2----------\n\r");
                  printf("0x%02x\n\r",  withlook[0]);
                  printf("0x%02x\n\r",  withlook[1]);
                  printf("0x%02x\n\r",  withlook[2]);
                  printf("0x%02x\n\r",  withlook[3]);
                  printf("0x%02x\n\r",  withlook[4]);
                  if(withlook[4]==0xf1)
                  weather_flag=1;
              }    
          }
          bflb_uart_int_clear(uart0, UART_INTCLR_RTO);
      }
}

static void uart0_init()
{
    struct bflb_device_s *gpio;

    gpio = bflb_device_get_by_name("gpio");
    bflb_gpio_uart_init(gpio, GPIO_PIN_21, GPIO_UART_FUNC_UART0_TX);
    bflb_gpio_uart_init(gpio, GPIO_PIN_22, GPIO_UART_FUNC_UART0_RX);

    struct bflb_uart_config_s cfg;
    cfg.baudrate = 115200;
    cfg.data_bits = UART_DATA_BITS_8;
    cfg.stop_bits = UART_STOP_BITS_1;
    cfg.parity = UART_PARITY_NONE;
    cfg.flow_ctrl = 0;
    cfg.tx_fifo_threshold = 7;
    cfg.rx_fifo_threshold = 7;

    uart0 = bflb_device_get_by_name("uart0");
    bflb_uart_init(uart0, &cfg);

	bflb_uart_rxint_mask(uart0, false);
	bflb_irq_attach(uart0->irq_num, uart0_isr, NULL);
	bflb_irq_enable(uart0->irq_num);
}

static void uart1_init()
{
    struct bflb_device_s *gpio;

    gpio = bflb_device_get_by_name("gpio");
    bflb_gpio_uart_init(gpio, GPIO_PIN_23, GPIO_UART_FUNC_UART1_TX);
    bflb_gpio_uart_init(gpio, GPIO_PIN_24, GPIO_UART_FUNC_UART1_RX);

    struct bflb_uart_config_s cfg;
    cfg.baudrate = 115200;
    cfg.data_bits = UART_DATA_BITS_8;
    cfg.stop_bits = UART_STOP_BITS_1;
    cfg.parity = UART_PARITY_NONE;
    cfg.flow_ctrl = 0;
    cfg.tx_fifo_threshold = 7;
    cfg.rx_fifo_threshold = 7;

    uart1 = bflb_device_get_by_name("uart1");
    bflb_uart_init(uart1, &cfg);

	bflb_uart_rxint_mask(uart1, false);
	bflb_irq_attach(uart1->irq_num, uart_isr, NULL);
	bflb_irq_enable(uart1->irq_num);
}

void io_init()
{
    bflb_gpio_init(gpio, GPIO_PIN_17, GPIO_OUTPUT | GPIO_PULLDOWN | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_18, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_10, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_11, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_12, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_16, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_32, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
    bflb_gpio_init(gpio, GPIO_PIN_20, GPIO_OUTPUT | GPIO_PULLUP | GPIO_SMT_EN | GPIO_DRV_0);
    bflb_mtimer_delay_ms(10);
}

void send_io(int data)  
{
   if((data/100000)%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_17);printf("0");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_17);printf("1");}
   if((data/10000)%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_18);printf("0");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_18);printf("1");}
   if((data/1000)%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_10);printf("0");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_10);printf("1");}
   if((data/100)%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_11);printf("0");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_11);printf("1");}
   if((data/10)%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_12);printf("0");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_12);printf("1");}
   if(data%10==0) {bflb_gpio_reset(gpio, GPIO_PIN_16);printf("0\n\r");}// 111 111
   else {bflb_gpio_set(gpio, GPIO_PIN_16);printf("1\n\r");}
}

void esp32_send()
{
   int weather = 100000,temp=110000;
   char dat=0;
   uint8_t i=0;
   if(withlook[1]==0x01) weather += 0;          //晴天
   else if(withlook[1]==0x03) weather += 100;   //阴天
   else if(withlook[1]==0x21) weather += 1000;  //小雨
   else if(withlook[1]==0x22) weather += 1100;  //中雨
   else if(withlook[1]==0x04) weather += 0;     //多云
   else if(withlook[1]==0x23) weather += 1100;  //大雨
   else if(withlook[1]==0x02) weather += 1000;  //雨
   dat = withlook[2];
   if(dat%4==0) weather+=0;
   else if(dat%4==2) weather+=1;
   else if(dat%4==1)weather+=10;
   else if(dat%4==3)weather+=11;
   printf("weather:");
   send_io(weather);
   bflb_mtimer_delay_ms(2000);

   if(dat>=32) {dat-=32;temp+=1;}
   if(dat>=16) {dat-=16;temp+=10;}
   if(dat>=8)  {dat-=8;temp+=100;}
   if(dat>=4)  {temp+=1000;}
   printf("temp:");
   send_io(temp);

   for(i=0;i<5;i++)
   {
     withlook[i]=0;
   }
}

void mpu6050_get()
{
    MPU6050_GetData(&AX, &AY, &AZ, &GX, &GY, &GZ);
    acceleration_magnitude = sqrt(AX*AX + AY*AY + AZ*AZ);
    // printf("amt=%.1f\n\r",acceleration_magnitude);
    if((acceleration_magnitude>=2200)&&(walk_mode==1)) {bflb_uart_put(uart1,walk_num,1);printf("------------walk--------------\n\r");}
    if(acceleration_magnitude>=2550) {show_light=1;printf("-----------------------light----------------------\n\r");}
    if(acceleration_magnitude>=5500) {fall_down=1;bflb_uart_put(uart1,walk_num2,1);printf("------------fall down--------------\n\r");}
}
int main(void)
{
    board_i2c0_gpio_init();
    board_init();
    gpio = bflb_device_get_by_name("gpio");
    adc = bflb_device_get_by_name("adc");
    uart1_init();
    uart0_init();
    io_init();
    MAX30102_Init();
    MPU6050_Init();
    while (1) 
    {
       if(esp8266_send==1) bflb_uart_put(uart0,nihao,1);
       if(weather_flag==1) {esp32_send();weather_flag=0;esp8266_send=0;}
       mpu6050_get();
    }
}